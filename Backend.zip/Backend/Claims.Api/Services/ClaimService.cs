using Claims.Api.Contracts;
using Claims.Api.Data;
using Claims.Api.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Storage;

namespace Claims.Api.Services;

public class ClaimService : IClaimService
{
    private readonly ClaimsDbContext context;
    private readonly ClaimDatabase database;

    public ClaimService(ClaimsDbContext context, ClaimDatabase database)
    {
        this.context = context;
        this.database = database;
    }

    public async Task<PagedClaimsResponse> SearchAsync(
        SearchClaimsRequest request, CancellationToken cancellationToken)
    {
        ClaimValidation.ValidateSearch(request);
        await database.Gate.WaitAsync(cancellationToken);

        try
        {
            IQueryable<ClaimRequest> query = context.Claims.AsNoTracking();

            if (request.Status != null)
            {
                ClaimStatus status = Enum.Parse<ClaimStatus>(request.Status);
                query = from claim in query where claim.Status == status select claim;
            }

            if (request.PolicyNumber != null)
            {
                query = from claim in query
                        where claim.PolicyNumber == request.PolicyNumber
                        select claim;
            }

            int totalCount = await query.CountAsync(cancellationToken);
            int offset = (request.Page - 1) * request.PageSize;

            IQueryable<ClaimDto> pageQuery =
                from claim in query
                orderby claim.SubmittedUtc descending, claim.Id descending
                select new ClaimDto
                {
                    Id = claim.Id,
                    ReferenceNumber = claim.ReferenceNumber,
                    PolicyNumber = claim.PolicyNumber,
                    ClaimType = claim.ClaimType.ToString(),
                    Amount = claim.Amount,
                    Status = claim.Status.ToString(),
                    SubmittedUtc = DateTime.SpecifyKind(claim.SubmittedUtc, DateTimeKind.Utc)
                };

            PagedClaimsResponse response = new PagedClaimsResponse();
            response.TotalCount = totalCount;
            response.Page = request.Page;
            response.PageSize = request.PageSize;
            response.Items = await pageQuery.Skip(offset).Take(request.PageSize).ToListAsync(cancellationToken);
            return response;
        }
        finally
        {
            database.Gate.Release();
        }
    }

    public async Task<CreateClaimResult> CreateAsync(
        string? idempotencyKey, CreateClaimRequest request, CancellationToken cancellationToken)
    {
        ClaimValidation.ValidateCreate(idempotencyKey, request);
        string key = idempotencyKey!.Trim();
        await database.Gate.WaitAsync(cancellationToken);

        try
        {
            IQueryable<ClaimRequest> existingQuery =
                from claim in context.Claims.AsNoTracking()
                where claim.IdempotencyKey == key
                select claim;

            ClaimRequest? existing = await existingQuery.SingleOrDefaultAsync(cancellationToken);
            if (existing != null)
            {
                if (existing.PolicyNumber != request.PolicyNumber ||
                    existing.ClaimType.ToString() != request.ClaimType ||
                    existing.Amount != request.Amount)
                {
                    throw new ClaimServiceException(
                        StatusCodes.Status409Conflict,
                        "IdempotencyConflict",
                        "This idempotency key has already been used with a different request.",
                        new Dictionary<string, string[]>());
                }

                return new CreateClaimResult(ToDto(existing), true);
            }

            await using (IDbContextTransaction transaction =
                         await context.Database.BeginTransactionAsync(cancellationToken))
            {
                IQueryable<int?> ids = from savedClaim in context.Claims select (int?)savedClaim.Id;
                int? maximumId = await ids.MaxAsync(cancellationToken);
                int nextId = 1;
                if (maximumId.HasValue)
                {
                    nextId = maximumId.Value + 1;
                }

                if (nextId > 8999)
                {
                    throw new InvalidOperationException("The four-digit claim reference range is exhausted.");
                }

                ClaimRequest claim = new ClaimRequest();
                claim.ReferenceNumber = "CLM-" + (1000 + nextId).ToString("D4");
                claim.PolicyNumber = request.PolicyNumber!;
                claim.ClaimType = Enum.Parse<ClaimType>(request.ClaimType!);
                claim.Amount = request.Amount!.Value;
                claim.Status = ClaimStatus.Submitted;
                claim.SubmittedUtc = DateTime.UtcNow;
                claim.IdempotencyKey = key;

                context.Claims.Add(claim);
                await context.SaveChangesAsync(cancellationToken);
                await transaction.CommitAsync(cancellationToken);

                return new CreateClaimResult(ToDto(claim), false);
            }
        }
        finally
        {
            database.Gate.Release();
        }
    }

    private static ClaimDto ToDto(ClaimRequest claim)
    {
        ClaimDto dto = new ClaimDto();
        dto.Id = claim.Id;
        dto.ReferenceNumber = claim.ReferenceNumber;
        dto.PolicyNumber = claim.PolicyNumber;
        dto.ClaimType = claim.ClaimType.ToString();
        dto.Amount = claim.Amount;
        dto.Status = claim.Status.ToString();
        dto.SubmittedUtc = DateTime.SpecifyKind(claim.SubmittedUtc, DateTimeKind.Utc);
        return dto;
    }
}
