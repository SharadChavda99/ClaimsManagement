namespace Claims.Api.Contracts;

public class SearchClaimsRequest
{
    public string? Status { get; set; }
    public string? PolicyNumber { get; set; }
    public int Page { get; set; } = 1;
    public int PageSize { get; set; } = 5;
}
