using Claims.Api.Contracts;

namespace Claims.Api.Services;

public interface IClaimService
{
    Task<PagedClaimsResponse> SearchAsync(SearchClaimsRequest request, CancellationToken cancellationToken);
    Task<CreateClaimResult> CreateAsync(
        string? idempotencyKey, CreateClaimRequest request, CancellationToken cancellationToken);
}
