using System.Collections.Concurrent;
using Microsoft.Extensions.Logging;

namespace Claims.Api.Tests;

public sealed class TestLogProvider : ILoggerProvider
{
    public ConcurrentQueue<string> Entries { get; } = new ConcurrentQueue<string>();

    public ILogger CreateLogger(string categoryName)
    {
        return new TestLogger(Entries);
    }

    public void Dispose()
    {
    }

    private sealed class TestLogger : ILogger
    {
        private readonly ConcurrentQueue<string> entries;

        public TestLogger(ConcurrentQueue<string> entries)
        {
            this.entries = entries;
        }

        public IDisposable? BeginScope<TState>(TState state) where TState : notnull
        {
            return null;
        }

        public bool IsEnabled(LogLevel logLevel)
        {
            return true;
        }

        public void Log<TState>(
            LogLevel logLevel, EventId eventId, TState state,
            Exception? exception, Func<TState, Exception?, string> formatter)
        {
            entries.Enqueue(formatter(state, exception));
        }
    }
}
