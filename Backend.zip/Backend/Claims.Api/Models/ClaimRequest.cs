namespace Claims.Api.Models;

public class ClaimRequest
{
    public int Id { get; set; }
    public string ReferenceNumber { get; set; } = string.Empty;
    public string PolicyNumber { get; set; } = string.Empty;
    public ClaimType ClaimType { get; set; }
    public decimal Amount { get; set; }
    public ClaimStatus Status { get; set; }
    public DateTime SubmittedUtc { get; set; }
    public string IdempotencyKey { get; set; } = string.Empty;
}
