namespace Claims.Api.Contracts;

public class ApiError
{
    public ApiError(string code, string message, string correlationId, Dictionary<string, string[]> errors)
    {
        Code = code;
        Message = message;
        CorrelationId = correlationId;
        Errors = errors;
    }

    public string Code { get; }
    public string Message { get; }
    public string CorrelationId { get; }
    public Dictionary<string, string[]> Errors { get; }
}
