using System.Net;
using System.Net.Http.Json;
using System.Text;
using System.Text.Json;
using Claims.Api.Contracts;
using Claims.Api.Data;
using Claims.Api.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;

namespace Claims.Api.Tests;

public class ClaimsWorkflowTests
{
    [Fact]
    public async Task SearchReturnsExactSeedOrderAndDefaults()
    {
        using ClaimsApiFactory factory = new ClaimsApiFactory();
        using HttpClient client = factory.CreateClient();

        PagedClaimsResponse page = await ReadPage(client, "/api/claims");

        Assert.Equal(6, page.TotalCount);
        Assert.Equal(1, page.Page);
        Assert.Equal(5, page.PageSize);
        Assert.Equal(new[] { "CLM-1006", "CLM-1005", "CLM-1004", "CLM-1003", "CLM-1002" },
            GetReferences(page));

        PagedClaimsResponse second = await ReadPage(client, "/api/claims?page=2");
        ClaimDto last = Assert.Single(second.Items);
        Assert.Equal("CLM-1001", last.ReferenceNumber);
        Assert.Equal(1250m, last.Amount);
        Assert.Equal(new DateTime(2026, 9, 1, 9, 0, 0, DateTimeKind.Utc), last.SubmittedUtc);
        Assert.Equal(DateTimeKind.Utc, last.SubmittedUtc.Kind);
    }

    [Fact]
    public async Task SearchCombinesExactFiltersAndReturnsAccurateTotal()
    {
        using ClaimsApiFactory factory = new ClaimsApiFactory();
        using HttpClient client = factory.CreateClient();

        PagedClaimsResponse page = await ReadPage(client,
            "/api/claims?status=Submitted&policyNumber=POL-2001&page=1&pageSize=1");
        Assert.Equal(2, page.TotalCount);
        Assert.Equal("CLM-1003", Assert.Single(page.Items).ReferenceNumber);

        PagedClaimsResponse next = await ReadPage(client,
            "/api/claims?status=Submitted&policyNumber=POL-2001&page=2&pageSize=1");
        Assert.Equal("CLM-1001", Assert.Single(next.Items).ReferenceNumber);

        PagedClaimsResponse empty = await ReadPage(client, "/api/claims?policyNumber=POL-9999");
        Assert.Empty(empty.Items);
        Assert.Equal(0, empty.TotalCount);

        PagedClaimsResponse beyond = await ReadPage(client, "/api/claims?page=100");
        Assert.Empty(beyond.Items);
        Assert.Equal(6, beyond.TotalCount);
    }

    [Theory]
    [InlineData("status=Unknown")]
    [InlineData("status=0")]
    [InlineData("status=submitted")]
    [InlineData("policyNumber=POL-200")]
    [InlineData("policyNumber=POL-2001x")]
    [InlineData("page=0")]
    [InlineData("page=-1")]
    [InlineData("page=abc")]
    [InlineData("pageSize=0")]
    [InlineData("pageSize=21")]
    [InlineData("page=2147483647&pageSize=20")]
    public async Task InvalidSearchReturnsCorrelatedFieldErrors(string query)
    {
        using ClaimsApiFactory factory = new ClaimsApiFactory();
        using HttpClient client = factory.CreateClient();
        client.DefaultRequestHeaders.Add("X-Correlation-ID", "search-validation-test");

        using HttpResponseMessage response = await client.GetAsync("/api/claims?" + query);
        ApiError error = await ReadError(response, HttpStatusCode.BadRequest, "ValidationFailed");
        Assert.NotEmpty(error.Errors);
        Assert.Equal("search-validation-test", error.CorrelationId);
        Assert.Contains(factory.Logs.Entries, ContainsSearchCorrelation);
    }

    [Fact]
    public async Task CreateAndReplayReturnSameClaimWithoutExposingKey()
    {
        using ClaimsApiFactory factory = new ClaimsApiFactory();
        using HttpClient client = factory.CreateClient();
        CreateClaimRequest body = ValidBody();

        using HttpResponseMessage created = await Post(client, "  retry-key-0001  ", body, "create-first");
        Assert.Equal(HttpStatusCode.Created, created.StatusCode);
        ClaimDto first = await ReadClaim(created);
        Assert.Equal("CLM-1007", first.ReferenceNumber);
        Assert.Equal("Submitted", first.Status);
        Assert.Equal("POL-2005", first.PolicyNumber);
        Assert.Equal("Motor", first.ClaimType);
        Assert.Equal(640m, first.Amount);

        using HttpResponseMessage replay = await Post(client, "retry-key-0001", body, "create-replay");
        Assert.Equal(HttpStatusCode.OK, replay.StatusCode);
        ClaimDto repeated = await ReadClaim(replay);
        Assert.Equal(first.Id, repeated.Id);
        Assert.Equal(first.SubmittedUtc, repeated.SubmittedUtc);
        Assert.Equal(first.ReferenceNumber, repeated.ReferenceNumber);

        string responseJson = await replay.Content.ReadAsStringAsync();
        Assert.DoesNotContain("idempotency", responseJson, StringComparison.OrdinalIgnoreCase);
        Assert.DoesNotContain("retry-key-0001", responseJson);
        Assert.Equal(7, (await ReadPage(client, "/api/claims")).TotalCount);

        string logs = string.Join("\n", factory.Logs.Entries);
        Assert.Contains("Outcome: Created", logs);
        Assert.Contains("Outcome: Replayed", logs);
        Assert.Contains("ReferenceNumber: CLM-1007", logs);
        Assert.DoesNotContain("POL-2005", logs);
        Assert.DoesNotContain("retry-key-0001", logs);
        Assert.DoesNotContain("640", logs);
        Assert.Equal(2, CountCreateEntries(factory.Logs));
    }

    [Theory]
    [InlineData("policy")]
    [InlineData("type")]
    [InlineData("amount")]
    public async Task ReusingKeyWithDifferentBodyReturnsConflict(string changedField)
    {
        using ClaimsApiFactory factory = new ClaimsApiFactory();
        using HttpClient client = factory.CreateClient();
        CreateClaimRequest body = ValidBody();
        using HttpResponseMessage created = await Post(client, "conflict-key-0001", body);
        Assert.Equal(HttpStatusCode.Created, created.StatusCode);

        if (changedField == "policy")
        {
            body.PolicyNumber = "POL-9999";
        }
        else if (changedField == "type")
        {
            body.ClaimType = "Travel";
        }
        else
        {
            body.Amount = 641m;
        }

        using HttpResponseMessage response = await Post(client, "conflict-key-0001", body);
        await ReadError(response, HttpStatusCode.Conflict, "IdempotencyConflict");
        Assert.Equal(7, (await ReadPage(client, "/api/claims")).TotalCount);
    }

    [Fact]
    public async Task ConcurrentRetriesCreateExactlyOneClaim()
    {
        using ClaimsApiFactory factory = new ClaimsApiFactory();
        using HttpClient client = factory.CreateClient();
        List<Task<HttpResponseMessage>> requests = new List<Task<HttpResponseMessage>>();
        for (int index = 0; index < 12; index++)
        {
            requests.Add(Post(client, "concurrent-retry-key", ValidBody()));
        }

        HttpResponseMessage[] responses = await Task.WhenAll(requests);
        int createdCount = 0;
        foreach (HttpResponseMessage response in responses)
        {
            using (response)
            {
                if (response.StatusCode == HttpStatusCode.Created)
                {
                    createdCount++;
                }
                else
                {
                    Assert.Equal(HttpStatusCode.OK, response.StatusCode);
                }

                Assert.Equal("CLM-1007", (await ReadClaim(response)).ReferenceNumber);
            }
        }

        Assert.Equal(1, createdCount);
        Assert.Equal(7, (await ReadPage(client, "/api/claims")).TotalCount);
    }

    [Fact]
    public async Task ConcurrentDifferentSubmissionsReceiveUniqueReferences()
    {
        using ClaimsApiFactory factory = new ClaimsApiFactory();
        using HttpClient client = factory.CreateClient();
        List<Task<HttpResponseMessage>> requests = new List<Task<HttpResponseMessage>>();
        for (int index = 0; index < 8; index++)
        {
            requests.Add(Post(client, "separate-request-" + index, ValidBody()));
        }

        HttpResponseMessage[] responses = await Task.WhenAll(requests);
        HashSet<string> references = new HashSet<string>();
        foreach (HttpResponseMessage response in responses)
        {
            using (response)
            {
                Assert.Equal(HttpStatusCode.Created, response.StatusCode);
                references.Add((await ReadClaim(response)).ReferenceNumber);
            }
        }

        Assert.Equal(8, references.Count);
        Assert.Equal(14, (await ReadPage(client, "/api/claims")).TotalCount);
    }

    [Theory]
    [InlineData(null)]
    [InlineData("")]
    [InlineData("short")]
    [InlineData("       ")]
    [InlineData("12345678901234567890123456789012345678901234567890123456789012345")]
    public async Task InvalidHeaderIsRejectedBeforeCreation(string? key)
    {
        using ClaimsApiFactory factory = new ClaimsApiFactory();
        using HttpClient client = factory.CreateClient();
        using HttpResponseMessage response = await Post(client, key, ValidBody());
        ApiError error = await ReadError(response, HttpStatusCode.BadRequest, "ValidationFailed");
        Assert.Contains("idempotencyKey", error.Errors.Keys);
        Assert.Equal(6, (await ReadPage(client, "/api/claims")).TotalCount);
    }

    [Theory]
    [InlineData("{\"policyNumber\":\"POL-2005\",\"claimType\":\"Motor\",\"amount\":0}")]
    [InlineData("{\"policyNumber\":\"POL-2005\",\"claimType\":\"Motor\",\"amount\":-1}")]
    [InlineData("{\"policyNumber\":\"POL-2005\",\"claimType\":\"Motor\",\"amount\":50000.01}")]
    [InlineData("{\"policyNumber\":\"POL-2005\",\"claimType\":\"Motor\",\"amount\":1.001}")]
    [InlineData("{\"policyNumber\":\"POL-2005\",\"claimType\":\"motor\",\"amount\":1}")]
    [InlineData("{\"policyNumber\":\"POL-2005\",\"claimType\":\"0\",\"amount\":1}")]
    [InlineData("{\"policyNumber\":\"POL-20050\",\"claimType\":\"Motor\",\"amount\":1}")]
    [InlineData("{\"policyNumber\":\"POL-2005\\n\",\"claimType\":\"Motor\",\"amount\":1}")]
    [InlineData("{\"policyNumber\":\"POL-2005\",\"claimType\":\"Motor\"}")]
    [InlineData("{}")]
    [InlineData("null")]
    [InlineData("{")]
    [InlineData("{\"amount\":\"not-a-number\"}")]
    public async Task InvalidBodyReturnsSafeFieldErrorsAndDoesNotCreateClaim(string json)
    {
        using ClaimsApiFactory factory = new ClaimsApiFactory();
        using HttpClient client = factory.CreateClient();
        using HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Post, "/api/claims");
        request.Headers.Add("Idempotency-Key", "invalid-body-key");
        request.Content = new StringContent(json, Encoding.UTF8, "application/json");
        using HttpResponseMessage response = await client.SendAsync(request);
        ApiError error = await ReadError(response, HttpStatusCode.BadRequest, "ValidationFailed");
        Assert.NotEmpty(error.Errors);
        Assert.Equal(6, (await ReadPage(client, "/api/claims")).TotalCount);
    }

    [Fact]
    public async Task ValidationRunsBeforeLookingUpExistingKey()
    {
        using ClaimsApiFactory factory = new ClaimsApiFactory();
        using HttpClient client = factory.CreateClient();
        CreateClaimRequest body = ValidBody();
        using HttpResponseMessage first = await Post(client, "validation-order-key", body);
        Assert.Equal(HttpStatusCode.Created, first.StatusCode);

        body.Amount = -1;
        using HttpResponseMessage invalid = await Post(client, "validation-order-key", body);
        await ReadError(invalid, HttpStatusCode.BadRequest, "ValidationFailed");
    }

    [Theory]
    [InlineData("0.01")]
    [InlineData("50000")]
    public async Task AmountBoundariesAreAccepted(string amount)
    {
        using ClaimsApiFactory factory = new ClaimsApiFactory();
        using HttpClient client = factory.CreateClient();
        CreateClaimRequest body = ValidBody();
        body.Amount = decimal.Parse(amount, System.Globalization.CultureInfo.InvariantCulture);
        using HttpResponseMessage response = await Post(client, "boundary-amount-key", body);
        Assert.Equal(HttpStatusCode.Created, response.StatusCode);
    }

    [Fact]
    public async Task DatabaseUniqueIndexRejectsDuplicateKeysEvenOutsideService()
    {
        using ClaimsApiFactory factory = new ClaimsApiFactory();
        using HttpClient client = factory.CreateClient();
        using IServiceScope scope = factory.Services.CreateScope();
        ClaimsDbContext context = scope.ServiceProvider.GetRequiredService<ClaimsDbContext>();

        ClaimRequest duplicate = new ClaimRequest();
        duplicate.ReferenceNumber = "CLM-9999";
        duplicate.PolicyNumber = "POL-9999";
        duplicate.ClaimType = ClaimType.Travel;
        duplicate.Amount = 1;
        duplicate.Status = ClaimStatus.Submitted;
        duplicate.SubmittedUtc = DateTime.UtcNow;
        duplicate.IdempotencyKey = "seed-claim-1";
        context.Claims.Add(duplicate);

        await Assert.ThrowsAsync<DbUpdateException>(Save);

        async Task Save()
        {
            await context.SaveChangesAsync();
        }
    }

    [Theory]
    [InlineData(true)]
    [InlineData(false)]
    public async Task UnexpectedFailuresAreGenericCorrelatedAndDoNotLogSensitiveDetails(bool create)
    {
        using ClaimsApiFactory factory = new ClaimsApiFactory(true);
        using HttpClient client = factory.CreateClient();
        client.DefaultRequestHeaders.Add("X-Correlation-ID", "support-failure-123");
        HttpResponseMessage response;
        if (create)
        {
            response = await Post(client, "failure-test-key", ValidBody());
        }
        else
        {
            response = await client.GetAsync("/api/claims");
        }

        using (response)
        {
            ApiError error = await ReadError(response, HttpStatusCode.InternalServerError, "UnexpectedError");
            Assert.Equal("support-failure-123", error.CorrelationId);
            string json = await response.Content.ReadAsStringAsync();
            Assert.DoesNotContain("InvalidOperationException", json);
            Assert.DoesNotContain("confidential", json);
        }

        string logs = string.Join("\n", factory.Logs.Entries);
        Assert.Contains("support-failure-123", logs);
        Assert.Contains("InvalidOperationException", logs);
        Assert.DoesNotContain("confidential", logs);
        Assert.DoesNotContain("POL-2005", logs);
        Assert.DoesNotContain("failure-test-key", logs);
    }

    [Fact]
    public async Task UnsafeCorrelationIdIsReplacedWithGeneratedId()
    {
        using ClaimsApiFactory factory = new ClaimsApiFactory();
        using HttpClient client = factory.CreateClient();
        client.DefaultRequestHeaders.TryAddWithoutValidation("X-Correlation-ID", "unsafe value with spaces");
        using HttpResponseMessage response = await client.GetAsync("/api/claims?page=0");
        ApiError error = await ReadError(response, HttpStatusCode.BadRequest, "ValidationFailed");
        Assert.Matches("^[a-f0-9]{32}$", error.CorrelationId);
    }

    [Fact]
    public async Task EqualTimestampsUseDescendingIdAsTieBreaker()
    {
        using ClaimsApiFactory factory = new ClaimsApiFactory();
        using HttpClient client = factory.CreateClient();
        using (IServiceScope scope = factory.Services.CreateScope())
        {
            ClaimsDbContext context = scope.ServiceProvider.GetRequiredService<ClaimsDbContext>();
            List<ClaimRequest> claims = await context.Claims.ToListAsync();
            foreach (ClaimRequest claim in claims)
            {
                claim.SubmittedUtc = new DateTime(2026, 9, 1, 9, 0, 0, DateTimeKind.Utc);
            }
            await context.SaveChangesAsync();
        }

        PagedClaimsResponse page = await ReadPage(client, "/api/claims?pageSize=20");
        Assert.Equal(new[] { "CLM-1006", "CLM-1005", "CLM-1004", "CLM-1003", "CLM-1002", "CLM-1001" },
            GetReferences(page));
    }

    private static CreateClaimRequest ValidBody()
    {
        CreateClaimRequest body = new CreateClaimRequest();
        body.PolicyNumber = "POL-2005";
        body.ClaimType = "Motor";
        body.Amount = 640m;
        return body;
    }

    private static async Task<HttpResponseMessage> Post(
        HttpClient client, string? key, CreateClaimRequest body, string? correlationId = null)
    {
        using HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Post, "/api/claims");
        if (key != null)
        {
            request.Headers.TryAddWithoutValidation("Idempotency-Key", key);
        }
        if (correlationId != null)
        {
            request.Headers.Add("X-Correlation-ID", correlationId);
        }
        request.Content = JsonContent.Create(body);
        return await client.SendAsync(request);
    }

    private static async Task<ClaimDto> ReadClaim(HttpResponseMessage response)
    {
        ClaimDto? claim = await response.Content.ReadFromJsonAsync<ClaimDto>();
        Assert.NotNull(claim);
        return claim;
    }

    private static async Task<PagedClaimsResponse> ReadPage(HttpClient client, string path)
    {
        using HttpResponseMessage response = await client.GetAsync(path);
        Assert.Equal(HttpStatusCode.OK, response.StatusCode);
        PagedClaimsResponse? page = await response.Content.ReadFromJsonAsync<PagedClaimsResponse>();
        Assert.NotNull(page);
        Assert.True(response.Headers.Contains("X-Correlation-ID"));
        string json = await response.Content.ReadAsStringAsync();
        Assert.DoesNotContain("idempotency", json, StringComparison.OrdinalIgnoreCase);
        return page;
    }

    private static async Task<ApiError> ReadError(
        HttpResponseMessage response, HttpStatusCode status, string code)
    {
        Assert.Equal(status, response.StatusCode);
        ApiError? error = await response.Content.ReadFromJsonAsync<ApiError>();
        Assert.NotNull(error);
        Assert.Equal(code, error.Code);
        Assert.Equal(response.Headers.GetValues("X-Correlation-ID").Single(), error.CorrelationId);
        using JsonDocument document = JsonDocument.Parse(await response.Content.ReadAsStringAsync());
        Assert.Equal(4, document.RootElement.EnumerateObject().Count());
        return error;
    }

    private static List<string> GetReferences(PagedClaimsResponse response)
    {
        List<string> references = new List<string>();
        foreach (ClaimDto item in response.Items)
        {
            references.Add(item.ReferenceNumber);
        }
        return references;
    }

    private static bool ContainsSearchCorrelation(string entry)
    {
        return entry.Contains("search-validation-test", StringComparison.Ordinal);
    }

    private static int CountCreateEntries(TestLogProvider logs)
    {
        int count = 0;
        foreach (string entry in logs.Entries)
        {
            if (entry.StartsWith("Claim create completed.", StringComparison.Ordinal))
            {
                count++;
            }
        }
        return count;
    }
}
