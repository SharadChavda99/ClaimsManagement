using Claims.Api.Contracts;

namespace Claims.Api.Services;

public class CreateClaimResult
{
    public CreateClaimResult(ClaimDto claim, bool replayed)
    {
        Claim = claim;
        Replayed = replayed;
    }

    public ClaimDto Claim { get; }
    public bool Replayed { get; }
}
