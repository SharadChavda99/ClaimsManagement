namespace Claims.Api.Models;

public enum ClaimStatus
{
    Submitted,
    InReview,
    Closed
}
