namespace Claims.Api.Contracts;

public class CreateClaimRequest
{
    public string? PolicyNumber { get; set; }
    public string? ClaimType { get; set; }
    public decimal? Amount { get; set; }
}
