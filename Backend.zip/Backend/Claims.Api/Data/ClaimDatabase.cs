using Microsoft.Data.Sqlite;

namespace Claims.Api.Data;

public sealed class ClaimDatabase : IDisposable
{
    public ClaimDatabase()
    {
        Connection = new SqliteConnection("Data Source=:memory:");
        Connection.Open();
    }

    public SqliteConnection Connection { get; }
    public SemaphoreSlim Gate { get; } = new SemaphoreSlim(1, 1);

    public void Dispose()
    {
        Connection.Dispose();
        Gate.Dispose();
    }
}
