namespace Claims.Api.Contracts;

public class PagedClaimsResponse
{
    public List<ClaimDto> Items { get; set; } = new List<ClaimDto>();
    public int TotalCount { get; set; }
    public int Page { get; set; }
    public int PageSize { get; set; }
}
