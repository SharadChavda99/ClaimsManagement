using System.Text.RegularExpressions;
using Claims.Api.Contracts;
using Claims.Api.Models;

namespace Claims.Api.Services;

public static class ClaimValidation
{
    public static void ValidateCreate(string? key, CreateClaimRequest request)
    {
        Dictionary<string, string[]> errors = new Dictionary<string, string[]>();

        if (string.IsNullOrWhiteSpace(key) || key.Trim().Length < 8 || key.Trim().Length > 64)
        {
            errors["idempotencyKey"] = new[] { "Provide one Idempotency-Key header with 8 to 64 trimmed characters." };
        }

        ValidatePolicyNumber(request.PolicyNumber, errors);

        if (!Enum.GetNames<ClaimType>().Contains(request.ClaimType, StringComparer.Ordinal))
        {
            errors["claimType"] = new[] { "Claim type must be Property, Motor or Travel." };
        }

        if (!request.Amount.HasValue || request.Amount.Value <= 0 || request.Amount.Value > 50000)
        {
            errors["amount"] = new[] { "Amount must be greater than 0 and no more than 50000." };
        }
        else if (decimal.Round(request.Amount.Value, 2) != request.Amount.Value)
        {
            errors["amount"] = new[] { "Amount must have no more than two decimal places." };
        }

        ThrowIfInvalid(errors);
    }

    public static void ValidateSearch(SearchClaimsRequest request)
    {
        Dictionary<string, string[]> errors = new Dictionary<string, string[]>();

        if (request.Status != null &&
            !Enum.GetNames<ClaimStatus>().Contains(request.Status, StringComparer.Ordinal))
        {
            errors["status"] = new[] { "Status must be Submitted, InReview or Closed." };
        }

        if (request.PolicyNumber != null)
        {
            ValidatePolicyNumber(request.PolicyNumber, errors);
        }

        if (request.Page < 1)
        {
            errors["page"] = new[] { "Page must be at least 1." };
        }

        if (request.PageSize < 1 || request.PageSize > 20)
        {
            errors["pageSize"] = new[] { "Page size must be between 1 and 20." };
        }

        long offset = ((long)request.Page - 1) * request.PageSize;
        if (offset > int.MaxValue)
        {
            errors["page"] = new[] { "The requested page exceeds the supported paging range." };
        }

        ThrowIfInvalid(errors);
    }

    private static void ValidatePolicyNumber(string? policyNumber, Dictionary<string, string[]> errors)
    {
        if (policyNumber == null || !Regex.IsMatch(policyNumber, @"\APOL-[0-9]{4}\z"))
        {
            errors["policyNumber"] = new[] { "Policy number must be POL- followed by four digits." };
        }
    }

    private static void ThrowIfInvalid(Dictionary<string, string[]> errors)
    {
        if (errors.Count > 0)
        {
            throw new ClaimServiceException(
                StatusCodes.Status400BadRequest,
                "ValidationFailed",
                "One or more request fields are invalid.",
                errors);
        }
    }
}
