using Claims.Api.Models;

namespace Claims.Api.Data;

public static class DatabaseInitializer
{
    public static void Initialize(ClaimsDbContext context)
    {
        context.Database.EnsureCreated();

        if (context.Claims.Any())
        {
            return;
        }

        context.Claims.AddRange(
            CreateSeed(1, "POL-2001", ClaimType.Property, 1250.00m, ClaimStatus.Submitted, 1),
            CreateSeed(2, "POL-2002", ClaimType.Motor, 480.50m, ClaimStatus.InReview, 3),
            CreateSeed(3, "POL-2001", ClaimType.Travel, 220.00m, ClaimStatus.Submitted, 5),
            CreateSeed(4, "POL-2003", ClaimType.Property, 7800.00m, ClaimStatus.Closed, 8),
            CreateSeed(5, "POL-2002", ClaimType.Motor, 1525.75m, ClaimStatus.Submitted, 10),
            CreateSeed(6, "POL-2004", ClaimType.Travel, 95.00m, ClaimStatus.Submitted, 12));

        context.SaveChanges();
    }

    private static ClaimRequest CreateSeed(
        int id, string policyNumber, ClaimType claimType, decimal amount, ClaimStatus status, int day)
    {
        ClaimRequest claim = new ClaimRequest();
        claim.Id = id;
        claim.ReferenceNumber = "CLM-" + (1000 + id).ToString("D4");
        claim.PolicyNumber = policyNumber;
        claim.ClaimType = claimType;
        claim.Amount = amount;
        claim.Status = status;
        claim.SubmittedUtc = new DateTime(2026, 9, day, 9, 0, 0, DateTimeKind.Utc);
        claim.IdempotencyKey = "seed-claim-" + id;
        return claim;
    }
}
