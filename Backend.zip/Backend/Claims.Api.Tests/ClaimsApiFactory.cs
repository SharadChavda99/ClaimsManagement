using Claims.Api.Services;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc.Testing;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.DependencyInjection.Extensions;
using Microsoft.Extensions.Logging;

namespace Claims.Api.Tests;

public class ClaimsApiFactory : WebApplicationFactory<Program>
{
    private readonly bool simulateFailure;

    public ClaimsApiFactory(bool simulateFailure = false)
    {
        this.simulateFailure = simulateFailure;
    }

    public TestLogProvider Logs { get; } = new TestLogProvider();

    protected override void ConfigureWebHost(IWebHostBuilder builder)
    {
        builder.ConfigureLogging(ConfigureLogging);
        builder.ConfigureServices(ConfigureServices);
    }

    private void ConfigureLogging(ILoggingBuilder logging)
    {
        logging.AddProvider(Logs);
    }

    private void ConfigureServices(IServiceCollection services)
    {
        if (simulateFailure)
        {
            services.RemoveAll<IClaimService>();
            services.AddScoped<IClaimService, FailingClaimService>();
        }
    }
}
