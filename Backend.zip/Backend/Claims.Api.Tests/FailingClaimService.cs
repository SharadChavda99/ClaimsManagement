using Claims.Api.Contracts;
using Claims.Api.Services;

namespace Claims.Api.Tests;

public class FailingClaimService : IClaimService
{
    public Task<PagedClaimsResponse> SearchAsync(
        SearchClaimsRequest request, CancellationToken cancellationToken)
    {
        throw new InvalidOperationException("Synthetic confidential details must not appear in logs.");
    }

    public Task<CreateClaimResult> CreateAsync(
        string? idempotencyKey, CreateClaimRequest request, CancellationToken cancellationToken)
    {
        throw new InvalidOperationException("Synthetic confidential details must not appear in logs.");
    }
}
