using Claims.Api.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Claims.Api.Data;

public class ClaimsDbContext : DbContext
{
    public ClaimsDbContext(DbContextOptions<ClaimsDbContext> options) : base(options)
    {
    }

    public DbSet<ClaimRequest> Claims
    {
        get { return Set<ClaimRequest>(); }
    }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        EntityTypeBuilder<ClaimRequest> claim = modelBuilder.Entity<ClaimRequest>();
        claim.HasKey(nameof(ClaimRequest.Id));
        claim.Property(nameof(ClaimRequest.ReferenceNumber)).HasMaxLength(8).IsRequired();
        claim.Property(nameof(ClaimRequest.PolicyNumber)).HasMaxLength(8).IsRequired();
        claim.Property(nameof(ClaimRequest.IdempotencyKey)).HasMaxLength(64).IsRequired();
        claim.Property<ClaimType>(nameof(ClaimRequest.ClaimType)).HasConversion<string>();
        claim.Property<ClaimStatus>(nameof(ClaimRequest.Status)).HasConversion<string>();
        claim.Property<decimal>(nameof(ClaimRequest.Amount)).HasPrecision(18, 2);
        claim.HasIndex(nameof(ClaimRequest.IdempotencyKey)).IsUnique();
        claim.HasIndex(nameof(ClaimRequest.ReferenceNumber)).IsUnique();
        claim.HasIndex(nameof(ClaimRequest.SubmittedUtc), nameof(ClaimRequest.Id));
    }
}
