using System.Diagnostics;
using System.Text.RegularExpressions;
using Claims.Api.Contracts;
using Claims.Api.Services;
using Microsoft.Extensions.Primitives;

namespace Claims.Api.Middleware;

public class ApiRequestMiddleware
{
    private readonly RequestDelegate next;
    private readonly ILogger<ApiRequestMiddleware> logger;

    public ApiRequestMiddleware(RequestDelegate next, ILogger<ApiRequestMiddleware> logger)
    {
        this.next = next;
        this.logger = logger;
    }

    public async Task InvokeAsync(HttpContext context)
    {
        string correlationId = GetCorrelationId(context.Request.Headers["X-Correlation-ID"]);
        context.TraceIdentifier = correlationId;
        context.Response.Headers["X-Correlation-ID"] = correlationId;
        Dictionary<string, object> scope = new Dictionary<string, object>();
        scope["CorrelationId"] = correlationId;
        Stopwatch stopwatch = Stopwatch.StartNew();

        using (logger.BeginScope(scope))
        {
            try
            {
                await next(context);

                if (context.Response.StatusCode >= 400 && !context.Response.HasStarted)
                {
                    if (context.Response.ContentType == null)
                    {
                        await WriteErrorAsync(context, context.Response.StatusCode,
                            "RequestRejected", "The request could not be processed.",
                            new Dictionary<string, string[]>());
                    }
                }
            }
            catch (ClaimServiceException exception)
            {
                await WriteErrorAsync(context, exception.StatusCode, exception.Code,
                    exception.Message, exception.Errors);
            }
            catch (OperationCanceledException) when (context.RequestAborted.IsCancellationRequested)
            {
                context.Response.StatusCode = 499;
                logger.LogWarning("Request cancelled. CorrelationId: {CorrelationId}", correlationId);
            }
            catch (Exception exception)
            {
                logger.LogError(
                    "Unexpected API failure. CorrelationId: {CorrelationId}; ExceptionType: {ExceptionType}",
                    correlationId, exception.GetType().FullName);

                if (context.Response.HasStarted)
                {
                    context.Abort();
                }
                else
                {
                    await WriteErrorAsync(context, StatusCodes.Status500InternalServerError,
                        "UnexpectedError", "An unexpected error occurred. Contact support with the correlation ID.",
                        new Dictionary<string, string[]>());
                }
            }
            finally
            {
                stopwatch.Stop();
                if (context.Response.StatusCode >= 400)
                {
                    logger.LogWarning(
                        "API request failed. CorrelationId: {CorrelationId}; StatusCode: {StatusCode}",
                        correlationId, context.Response.StatusCode);
                }

                if (HttpMethods.IsPost(context.Request.Method) &&
                    context.Request.Path.Equals("/api/claims", StringComparison.OrdinalIgnoreCase))
                {
                    string outcome = "Rejected";
                    string referenceNumber = "(none)";
                    if (context.Items["ClaimOutcome"] is string recordedOutcome)
                    {
                        outcome = recordedOutcome;
                    }
                    if (context.Items["ClaimReferenceNumber"] is string recordedReference)
                    {
                        referenceNumber = recordedReference;
                    }

                    logger.LogInformation(
                        "Claim create completed. CorrelationId: {CorrelationId}; ReferenceNumber: {ReferenceNumber}; Outcome: {Outcome}; ElapsedMs: {ElapsedMs}; StatusCode: {StatusCode}",
                        correlationId, referenceNumber, outcome, stopwatch.Elapsed.TotalMilliseconds,
                        context.Response.StatusCode);
                }
            }
        }
    }

    private static string GetCorrelationId(StringValues values)
    {
        if (values.Count == 1)
        {
            string? supplied = values[0];
            if (supplied != null && Regex.IsMatch(supplied, @"\A[A-Za-z0-9._-]{1,64}\z"))
            {
                return supplied;
            }
        }

        return Guid.NewGuid().ToString("N");
    }

    private static async Task WriteErrorAsync(
        HttpContext context, int statusCode, string code, string message,
        Dictionary<string, string[]> errors)
    {
        context.Response.StatusCode = statusCode;
        ApiError error = new ApiError(code, message, context.TraceIdentifier, errors);
        await context.Response.WriteAsJsonAsync(error, context.RequestAborted);
    }
}
