using Claims.Api.Contracts;
using Claims.Api.Data;
using Claims.Api.Middleware;
using Claims.Api.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace Claims.Api;

public class Program
{
    public static void Main(string[] args)
    {
        WebApplicationBuilder builder = WebApplication.CreateBuilder(args);

        builder.Services.AddSingleton<ClaimDatabase>();
        builder.Services.AddDbContext<ClaimsDbContext>(ConfigureDatabase);
        builder.Services.AddScoped<IClaimService, ClaimService>();
        builder.Services.AddControllers(ConfigureControllers)
            .ConfigureApiBehaviorOptions(ConfigureApiBehavior);

        WebApplication app = builder.Build();

        using (IServiceScope scope = app.Services.CreateScope())
        {
            ClaimsDbContext context = scope.ServiceProvider.GetRequiredService<ClaimsDbContext>();
            DatabaseInitializer.Initialize(context);
        }

        app.UseMiddleware<ApiRequestMiddleware>();
        app.MapControllers();
        app.Run();
    }

    private static void ConfigureDatabase(IServiceProvider services, DbContextOptionsBuilder options)
    {
        ClaimDatabase database = services.GetRequiredService<ClaimDatabase>();
        options.UseSqlite(database.Connection);
    }

    private static void ConfigureControllers(MvcOptions options)
    {
        options.SuppressImplicitRequiredAttributeForNonNullableReferenceTypes = true;
    }

    private static void ConfigureApiBehavior(ApiBehaviorOptions options)
    {
        options.InvalidModelStateResponseFactory = CreateInvalidModelResponse;
        options.SuppressMapClientErrors = true;
    }

    private static IActionResult CreateInvalidModelResponse(ActionContext context)
    {
        Dictionary<string, string[]> errors = new Dictionary<string, string[]>();

        foreach (KeyValuePair<string, Microsoft.AspNetCore.Mvc.ModelBinding.ModelStateEntry> entry
                 in context.ModelState)
        {
            if (entry.Value.Errors.Count > 0)
            {
                string field = entry.Key;
                if (string.IsNullOrWhiteSpace(field))
                {
                    field = "body";
                }

                errors[field] = new[] { "The field is missing or has an invalid format." };
            }
        }

        ApiError error = new ApiError(
            "ValidationFailed",
            "One or more request fields are invalid.",
            context.HttpContext.TraceIdentifier,
            errors);

        return new BadRequestObjectResult(error);
    }
}
