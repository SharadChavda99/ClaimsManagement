using Claims.Api.Contracts;
using Claims.Api.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Primitives;

namespace Claims.Api.Controllers;

[ApiController]
[Route("api/claims")]
public class ClaimsController : ControllerBase
{
    private readonly IClaimService service;

    public ClaimsController(IClaimService service)
    {
        this.service = service;
    }

    [HttpGet]
    [ProducesResponseType<PagedClaimsResponse>(StatusCodes.Status200OK)]
    [ProducesResponseType<ApiError>(StatusCodes.Status400BadRequest)]
    public async Task<ActionResult<PagedClaimsResponse>> Search(
        [FromQuery] SearchClaimsRequest request, CancellationToken cancellationToken)
    {
        PagedClaimsResponse response = await service.SearchAsync(request, cancellationToken);
        return Ok(response);
    }

    [HttpPost]
    [ProducesResponseType<ClaimDto>(StatusCodes.Status201Created)]
    [ProducesResponseType<ClaimDto>(StatusCodes.Status200OK)]
    [ProducesResponseType<ApiError>(StatusCodes.Status400BadRequest)]
    [ProducesResponseType<ApiError>(StatusCodes.Status409Conflict)]
    [ProducesResponseType<ApiError>(StatusCodes.Status500InternalServerError)]
    public async Task<ActionResult<ClaimDto>> Create(
        [FromBody] CreateClaimRequest request, CancellationToken cancellationToken)
    {
        string? key = null;
        StringValues values = Request.Headers["Idempotency-Key"];
        if (values.Count == 1)
        {
            key = values[0];
        }

        CreateClaimResult result = await service.CreateAsync(key, request, cancellationToken);
        HttpContext.Items["ClaimReferenceNumber"] = result.Claim.ReferenceNumber;
        if (result.Replayed)
        {
            HttpContext.Items["ClaimOutcome"] = "Replayed";
            return Ok(result.Claim);
        }

        HttpContext.Items["ClaimOutcome"] = "Created";
        return StatusCode(StatusCodes.Status201Created, result.Claim);
    }
}
