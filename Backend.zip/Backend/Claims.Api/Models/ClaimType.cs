namespace Claims.Api.Models;

public enum ClaimType
{
    Property,
    Motor,
    Travel
}
