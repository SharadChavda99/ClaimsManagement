namespace Claims.Api.Services;

public class ClaimServiceException : Exception
{
    public ClaimServiceException(
        int statusCode, string code, string message, Dictionary<string, string[]> errors)
        : base(message)
    {
        StatusCode = statusCode;
        Code = code;
        Errors = errors;
    }

    public int StatusCode { get; }
    public string Code { get; }
    public Dictionary<string, string[]> Errors { get; }
}
